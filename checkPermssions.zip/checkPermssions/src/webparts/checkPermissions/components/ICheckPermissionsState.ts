export interface ICheckPermissionsState{
    Data:JSX.Element;
}