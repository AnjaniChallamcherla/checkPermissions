import * as React from 'react';
import styles from './CheckPermissions.module.scss';
import { ICheckPermissionsProps } from './ICheckPermissionsProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { ICheckPermissionsState } from './ICheckPermissionsState';
import { sp, UrlFieldFormatType, PermissionKind } from '@pnp/sp';
export default class CheckPermissions extends React.Component<ICheckPermissionsProps, ICheckPermissionsState> {
  constructor(props) {
    super(props);
    sp.setup({
      sp: {
        baseUrl: this.props.siteUrl
      }
    });
    this.state = {
      Data: <div>Loading</div>
    };
  }
  public async componentDidMount() {
    this.setState({ Data: <div>Loading...Please wait</div> });
    await sp.web.userHasPermissions("i:0#.f|membership|" + this.props.currentUserEmail, PermissionKind.ManageLists).then(perms => {
      this.setState({Data:<div>UserPermissions: {perms}</div>});
      console.log("User:"+this.props.currentUserEmail+" Perms: "+perms);
    });

  }
  public render(): React.ReactElement<ICheckPermissionsProps> {
    return (
      <div className={ styles.checkPermissions }>
       {this.state.Data}
      </div>
    );
  }
}
