/* tslint:disable */
require("./CheckPermissions.module.css");
const styles = {
  checkPermissions: 'checkPermissions_110e5332',
  container: 'container_110e5332',
  row: 'row_110e5332',
  column: 'column_110e5332',
  'ms-Grid': 'ms-Grid_110e5332',
  title: 'title_110e5332',
  subTitle: 'subTitle_110e5332',
  description: 'description_110e5332',
  button: 'button_110e5332',
  label: 'label_110e5332',
};

export default styles;
/* tslint:enable */