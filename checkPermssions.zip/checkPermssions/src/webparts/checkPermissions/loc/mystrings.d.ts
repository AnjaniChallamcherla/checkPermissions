declare interface ICheckPermissionsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CheckPermissionsWebPartStrings' {
  const strings: ICheckPermissionsWebPartStrings;
  export = strings;
}
