/// <reference types="react" />
import * as React from 'react';
import { ICheckPermissionsProps } from './ICheckPermissionsProps';
import { ICheckPermissionsState } from './ICheckPermissionsState';
export default class CheckPermissions extends React.Component<ICheckPermissionsProps, ICheckPermissionsState> {
    constructor(props: any);
    componentDidMount(): Promise<void>;
    render(): React.ReactElement<ICheckPermissionsProps>;
}
