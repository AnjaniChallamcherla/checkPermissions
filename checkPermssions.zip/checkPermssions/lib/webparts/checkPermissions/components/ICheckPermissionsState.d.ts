/// <reference types="react" />
export interface ICheckPermissionsState {
    Data: JSX.Element;
}
