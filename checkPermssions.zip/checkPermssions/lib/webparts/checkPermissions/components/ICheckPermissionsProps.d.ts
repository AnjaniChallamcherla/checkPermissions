export interface ICheckPermissionsProps {
    siteUrl: string;
    currentUserEmail: string;
}
